# Site Real L.J

Este é o site oficial básico do artista **Real L.J**.

## 🚀 Como colocar no ar no GitHub Pages

1. Crie uma conta no [GitHub](https://github.com).
2. Crie um repositório chamado `real-lj-site`.
3. Faça upload dos arquivos `index.html`, `style.css` e `foto.jpg`.
4. Vá em **Settings > Pages** e escolha a branch `main` com a pasta `/root`.
5. Pronto! O GitHub Pages vai gerar um link do tipo:
   ```
   https://SEU_USUARIO.github.io/real-lj-site
   ```

Cole esse link nas suas redes sociais para divulgar! 🔥
